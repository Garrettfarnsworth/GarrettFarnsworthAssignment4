﻿using Assignment4.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
 
        public IActionResult Index()
        {
            List<string> restaurantList = new List<string>();

            foreach(Restaurant r in Restaurant.GetRestaurants())
            {
                //These are to account for nulls in the program and fill them in with these values for the approriate attributes of the object.
                string? dish = r.FavoriteDish ?? "It's all tasty!";

                string? site = r.RestuarantWebsite ?? "Coming soon.";

                string? number = r.RestaurantPhoneNumber ?? "000-000-0000";

                restaurantList.Add($"#{r.RestaurantRank}: {r.RestaurantName}: {dish}: " +
                    $"{r.Address}: {number}: {site})");
            }

            return View(restaurantList);
        }

        //Brings up the default page before the button is clicked and information entered.
        [HttpGet]
        public IActionResult EnterRestaurant()
        {
            return View();
        }

        //Post allows for the page to bring up the confirmation after the user has clicked the button. 
        [HttpPost]
        public IActionResult EnterRestaurant(RestaurantResponse appResponse)
        {
            //Validation so that the code doesn't show up on the restaurant list page if it isn't valid.
            if (ModelState.IsValid)
            {
                TempStorage.AddRestaurant(appResponse);
                return View("Confirmation", appResponse);
            }
            else
            {
                return View();
            }
        }
        public IActionResult RestaurantList()
        {
            return View(TempStorage.Recommendations);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
