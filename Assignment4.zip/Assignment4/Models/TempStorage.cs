﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//This page is for the array we make to output the restaurants.
namespace Assignment4.Models
{
    public static class TempStorage
    {
        private static List<RestaurantResponse> recommendations = new List<RestaurantResponse>();

        public static IEnumerable<RestaurantResponse> Recommendations => recommendations;

        public static void AddRestaurant(RestaurantResponse recommendation)
        {
            recommendations.Add(recommendation);
        }
    }
}