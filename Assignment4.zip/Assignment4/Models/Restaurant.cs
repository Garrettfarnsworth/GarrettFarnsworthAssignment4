﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4.Models
{
    public class Restaurant
    {
        //This makes it so that the rank is read only, hence it is only a get; and no set;
        public Restaurant(int rank)
        {
            RestaurantRank = rank;
        }
        [Required(ErrorMessage = "Please enter a rank")]
        public int RestaurantRank { get; }
        [Required(ErrorMessage = "Please enter the restaurants name")]
        public string RestaurantName { get; set; }
        //By addding an equal sign and sayings "It's all tasty!" we are adding a default value. 
        public string? FavoriteDish { get; set; } = "It's all tasty!";
        [Required(ErrorMessage = "Please enter an address for the restaurant")]
        public string Address { get; set; }
        //This makes sure that the user's phone number is entered in this specific way, or else it is not valid and displays the error message. 
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"\d{3}-\d{3}-\d{4}", ErrorMessage = "Please enter a valid Phone Number (###-###-####)")]
        public string? RestaurantPhoneNumber { get; set; } = "000-000-0000";
        public string? RestuarantWebsite { get; set; } = "Coming Soon.";

        //The list of my top 5 reccomendation restaurant objects and their attributes.
        public static  Restaurant[] GetRestaurants()
        {
            Restaurant r1 = new Restaurant(1)
            { 
                RestaurantName = "Shoga",
                //FavoriteDish = "Tonkatsu",
                Address = "Filler",
                RestaurantPhoneNumber = "954-270-4745",
                //RestuarantWebsite = "Blank.com"
            };

            Restaurant r2 = new Restaurant(2)
            {
                RestaurantName = "Happy Sumo",
                FavoriteDish = "Sushi",
                Address = "Filler",
                //RestaurantPhoneNumber = "954-270-4745",
                RestuarantWebsite = "Blank.com"
            };

            Restaurant r3 = new Restaurant(3)
            {
                RestaurantName = null,
                FavoriteDish = "Chicken Sandwhich",
                Address = "Filler",
                RestaurantPhoneNumber = null,
                RestuarantWebsite = "Blank.com"
            };

            Restaurant r4 = new Restaurant(4)
            {
                RestaurantName = "Umami",
                FavoriteDish = "Tonkatsu",
                Address = "Filler",
                RestaurantPhoneNumber = "954-270-4745",
                RestuarantWebsite = "Blank.com"
            };

            Restaurant r5 = new Restaurant(5)
            {
                RestaurantName = "K's Kitchen",
                FavoriteDish = null,
                Address = "Filler",
                RestaurantPhoneNumber = "954-270-4745",
                RestuarantWebsite = null
            };
            return new Restaurant[] { r1, r2, r3, r4, r5 };
        }
    }
}
