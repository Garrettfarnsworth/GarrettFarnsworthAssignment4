﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4.Models
{
    public class RestaurantResponse
    {
        [Required(ErrorMessage = "Please enter your name")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Please enter the restaurant name")]
        public string UserRestaurantName { get; set; }
        [Required(ErrorMessage = "Please enter your favorite dish")]
        public string? UserFavoriteDish { get; set; }
        //This makes sure that the user's phone number is entered in this specific way, or else it is not valid and displays the error message. 
        [Required(ErrorMessage = "Please enter your phone number i.e (###-###-####")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"\d{3}-\d{3}-\d{4}", ErrorMessage = "Please enter a valid Phone Number i.e (###-###-####)")]
        public string UserRestaurantPhoneNumber { get; set; }
    }
}
